#!/bin/bash
 umount $YDIR/yantra/repository||true
 umount $YDIR/dev/pts||true
 umount $YDIR/run||true
 umount $YDIR/sys||true
 umount $YDIR/proc||true
 umount $YDIR/dev||true
