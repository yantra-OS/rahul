#!/bin/bash

#COMPILER_SPECS=$(pwd)/yaps.build.conf
#source $COMPILER_SPECS
export YDIR=/yantra
export OSNAME='yantra'
export OSVERSION='0.1.0'
export SRCDIR=$YDIR/yantra/sources
export PKGDIR=$YDIR/yantra/packages
export WORKDIR=$YDIR/yantra/cache

mkdir -p $SRCDIR $PKGDIR $WORKDIR
[[ -d $TCDIR ]] || mkdir -p $TCDIR

export PATH=/tools/bin:$PATH
export REPOSITORY=$(pwd)/


#[[ -d /tools ]] && mv /tools{,.old}

ln -srvf $YDIR/tools /tools
[[ -d $YDIR/tools/installed ]] || mkdir -p $YDIR/tools/installed


for i in linux-api-headers glibc zlib file                    \
         readline m4 bc binutils gmp mpfr mpc shadow          \
         gcc bzip2 pkg-config ncurses attr acl libcap         \
         sed psmisc iana-etc bison flex grep bash libtool     \
         gdbm gperf expat inetutils perl xml-parser           \
         inettool autoconf xz kmod gettext elfutils           \
         libffi openssl python ninja meson coreutils          \
         check diffutils groff grub less gzip iproute2        \
         kbd libpipeline make patch man-db tar texinfo        \
         vim systemd dbus procps-ng util-linux e2fsprogs; do

    [[ -d $YDIR/usr/share/yaps/$i ]] && {
        echo "skipping $i, (already configured)"
        continue
    }

    echo "=> compiling $i"
    /usr/bin/yaps compile $i --no-depends --compiler-specs /yaps.build.conf

    case $i in
        glibc)
            [[ -e /tools/patched-toolchain ]] || {
                echo "adjusting toolchain"
                mv -v /tools/bin/{ld,ld-old}
                mv -v /tools/$(uname -m)-pc-linux-gnu/bin/{ld,ld-old}
                mv -v /tools/bin/{ld-new,ld}
                ln -sv /tools/bin/ld /tools/$(uname -m)-pc-linux-gnu/bin/ld

                gcc -dumpspecs | sed -e 's@/tools@@g'                   \
                    -e '/\*startfile_prefix_spec:/{n;s@.*@/usr/lib/ @}' \
                    -e '/\*cpp:/{n;s@$@ -isystem /usr/include@}' >      \
                    `dirname $(gcc --print-libgcc-file-name)`/specs

                touch /tools/patched-toolchain
            }

            echo "testing toolchain"
            echo 'int main(){}' > dummy.c

            cc dummy.c -v -Wl,--verbose &> dummy.log
            if [[ $(readelf -l a.out | grep ': /lib' | xargs) != '[Requesting program interpreter: /lib64/ld-linux-x86-64.so.2]' ]] ; then
                echo 'Toolchain interpreter fail' > /tools/tc-test-fail
                exit 1
            fi
            grep -o '/usr/lib.*/crt[1in].*succeeded' dummy.log || tee /tools/tc-test-fail
            grep -B1 '^ /usr/include' dummy.log || tee /tools/tc-test-fail
            grep 'SEARCH.*/usr/lib' dummy.log |sed 's|; |\n|g' || tee /tools/tc-test-fail
            grep "/lib.*/libc.so.6 " dummy.log || tee /tools/tc-test-fail
            grep found dummy.log || tee /tools/tc-test-fail
            rm -v dummy.c a.out dummy.log
            ;;
    esac

done
