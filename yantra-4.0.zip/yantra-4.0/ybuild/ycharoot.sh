
#!/bin/bash
COMPILER_SPECS=$(pwd)/yaps.build.conf
source $COMPILER_SPECS
export YDIR=/yantra
export OSNAME='yantra'
export OSVERSION='0.1.0'
export SRCDIR=$YDIR/yantra/sources
export PKGDIR=$YDIR/yantra/packages
export WORKDIR=$YDIR/yantra/cache
export PATH=/tools/bin:$PATH
export REPOSITORY=$(pwd)/
chown -R root:root $YDIR/tools
mkdir -p ${YDIR}/{boot,etc,var,mnt,opt,dev,proc,sys,run}


mount -v --bind /dev $YDIR/dev
mount -v -t proc proc $YDIR/proc
mount -v -t sysfs sysfs $YDIR/sys
mount -v -t tmpfs tmpfs $YDIR/run
mount -vt devpts devpts $YDIR/dev/pts -o gid=5,mode=620
mount --bind $(realpath .) $YDIR/yantra/repository

if [ -h $YDIR/dev/shm ]; then
  mkdir -pv $YDIR/$(readlink $YDIR/dev/shm)
fi

    chroot "$YDIR" /tools/bin/env -i \
    HOME=/root \
    TERM="$TERM" \
    PS1='(ycharoot) \u:\w \$ ' \
    PATH=/bin:/usr/bin:/sbin:/usr/sbin:/tools/bin \
    /tools/bin/bash --login +h

    mkdir -p ${YDIR}/{boot,etc,var,mnt,opt,dev,proc,sys,run}
    install -v -d -m 0750 $YDIR/root
    install -v -d -m 1777 $YDIR/tmp $YDIR/var/tmp
    mkdir -p ${YDIR}/usr/{,local/}{bin,include,lib,src}
    mkdir -p ${YDIR}/usr/{,local/}share/{color,dict,doc,info,locale,man}
    mkdir -p ${YDIR}/usr/{,local/}share/{misc,terminfo,zoneinfo}
    mkdir -p ${YDIR}/usr/{,local/}share/man/man{1..8}
    mkdir -p ${YDIR}/usr/lib/pkgconfig
    mkdir -p ${YDIR}/var/{log,mail,spool,opt,cache,lib/{color,misc,locate},local}


    ln -s usr/lib $YDIR/lib
    ln -s usr/lib $YDIR/lib64
    ln -s lib $YDIR/usr/lib64

    ln -s usr/bin $YDIR/bin
    ln -s usr/bin $YDIR/sbin
    ln -s bin $YDIR/usr/sbin

    ln -s ../run $YDIR/var/run
    ln -s ../run/lock $YDIR/var/lock

    ln -s ../proc/self/mounts $YDIR/etc/mtab

    cp files/{passwd,group} $YDIR/etc/
    touch $YDIR/var/log/{btmp,lastlog,faillog,wtmp}
    chgrp -v 13 $YDIR/var/log/lastlog
    chmod -v 664 $YDIR/var/log/lastlog
    chmod -v 600 $YDIR/var/log/btmp

    echo "$OSVERSION" > $YDIR/etc/yantra-release

    ln -sv /tools/bin/{bash,cat,chmod,dd,echo,ln,mkdir,pwd,rm,stty,touch} $YDIR/usr/bin/
    ln -sv /tools/bin/{env,install,perl,printf} $YDIR/usr/bin/
    ln -sv /tools/lib/libgcc_s.so{,.1} $YDIR/usr/lib/
    ln -sv /tools/lib/libstdc++.{a,so{,.6}} $YDIR/usr/lib/
    ln -sv bash $YDIR/usr/bin/sh
    
    if [[ $1 == "chroot" ]] ; then
  	  echo "Chrooting into system"
    	  ychroot /tools/bin/bash
          exit $?
    fi
