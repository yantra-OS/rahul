#!/bin/bash

COMPILER_SPECS=$(pwd)/yaps.build.conf
source $COMPILER_SPECS

export OSNAME='yantra'
export OSVERSION='0.1.0'
export SRCDIR=$YDIR/yantra/sources
export PKGDIR=$YDIR/yantra/packages
export WORKDIR=$YDIR/yantra/cache

mkdir -p $SRCDIR $PKGDIR $WORKDIR
[[ -d $TCDIR ]] || mkdir -p $TCDIR

export PATH=/tools/bin:$PATH
export REPOSITORY=$(pwd)/

[[ -d /tools ]] && mv /tools{,.old}

ln -srvf $YDIR/tools /tools
[[ -d $YDIR/tools/installed ]] || mkdir -p $YDIR/tools/installed

# toolchain
for i in binutils-pass1 gcc-pass1 kernel-api-headers glibc-tc \
         test-pass1 libstdc++-pass1 \
         binutils-pass2 gcc-pass2 \
         test-pass2 tcl-tc expect-tc \
         dejagnu-tc m4-tc ncurses-tc \
         bash-tc bison-tc bzip2-tc \
         coreutils-tc diffutils-tc \
         file-tc findutils-tc gawk-tc \
         gettext-tc grep-tc gzip-tc \
         make-tc patch-tc perl-tc \
         python-tc sed-tc tar-tc texinfo-tc \
         util-linux-tc xz-tc openssl-tc  yaps-tc wget-tc; do 
    [[ -e $YDIR/tools/installed/$i ]] && {
        echo "skipping $i, already configured"
        continue
    }
    echo "=> compiling $i"
    echo -e '\033k' compiling $i '\033\\'
    yaps compile $i --no-install --no-depends --compiler-specs $COMPILER_SPECS
    if [[ $? != 0 ]] ; then
        echo "ERROR failed to compile $i"
        exit 1
    fi

    touch $YDIR/tools/installed/$i
done

echo "** Toolchain completed **"

if [[ -z "${NO_BACKUP}" ]] ; then
    echo "backing up toolchain"
    mksquashfs $YDIR/tools toolchain-$(uname -m).squa || {
        echo "Failed to backup toolchain"
        exit 1
    }
fi

# system build
[[ -e "${YDIR}/etc/yantra-release" ]] || {
    echo "creating filesystem"

    mkdir -p ${YDIR}/{boot,etc,var,mnt,opt,dev,proc,sys,run}
    install -v -d -m 0750 $YDIR/root
    install -v -d -m 1777 $YDIR/tmp $YDIR/var/tmp
    mkdir -p ${YDIR}/usr/{,local/}{bin,include,lib,src}
    mkdir -p ${YDIR}/usr/{,local/}share/{color,dict,doc,info,locale,man}
    mkdir -p ${YDIR}/usr/{,local/}share/{misc,terminfo,zoneinfo}
    mkdir -p ${YDIR}/usr/{,local/}share/man/man{1..8}
    mkdir -p ${YDIR}/usr/lib/pkgconfig
    mkdir -p ${YDIR}/var/{log,mail,spool,opt,cache,lib/{color,misc,locate},local}
    

    ln -s usr/lib $YDIR/lib
    ln -s usr/lib $YDIR/lib64
    ln -s lib $YDIR/usr/lib64

    ln -s usr/bin $YDIR/bin
    ln -s usr/bin $YDIR/sbin
    ln -s bin $YDIR/usr/sbin

    ln -s ../run $YDIR/var/run
    ln -s ../run/lock $YDIR/var/lock

    ln -s ../proc/self/mounts $YDIR/etc/mtab

    cp files/{passwd,group} $YDIR/etc/
    touch $YDIR/var/log/{btmp,lastlog,faillog,wtmp}
    chgrp -v 13 $YDIR/var/log/lastlog
    chmod -v 664 $YDIR/var/log/lastlog
    chmod -v 600 $YDIR/var/log/btmp
    
    echo "$OSVERSION" > $YDIR/etc/yantra-release

    ln -sv /tools/bin/{bash,cat,chmod,dd,echo,ln,mkdir,pwd,rm,stty,touch} $YDIR/usr/bin/
    ln -sv /tools/bin/{env,install,perl,printf} $YDIR/usr/bin/
    ln -sv /tools/lib/libgcc_s.so{,.1} $YDIR/usr/lib/
    ln -sv /tools/lib/libstdc++.{a,so{,.6}} $YDIR/usr/lib/
    ln -sv bash $YDIR/usr/bin/sh
}

# ychroot <args>...
# execute command inside chroot
ychroot() {

    [[ -d $YDIR/yantra/repository ]] || mkdir -p $YDIR/yantra/repository

    _mount() {
        mount -v --bind /dev $YDIR/dev
        mount -v -t proc proc $YDIR/proc
        mount -v -t sysfs sysfs $YDIR/sys
        mount -v -t tmpfs tmpfs $YDIR/run
        mount -vt devpts devpts $YDIR/dev/pts -o gid=5,mode=620

        mount --bind $(realpath .) $YDIR/yantra/repository
    }

    _umount() {
        umount $YDIR/yantra/repository
        umount $YDIR/dev/pts
        umount $YDIR/run
        umount $YDIR/sys
        umount $YDIR/proc
        umount $YDIR/dev
    }


    # mount pseudo filesystem
    _mount

    echo "executing $@"
    # chroot command
    chroot "$YDIR" /tools/bin/env -i \
    HOME=/root \
    TERM="$TERM" \
    PS1='toolchain (yantra) \u:\w \$ ' \
    PATH=/usr/bin:/tools/bin \
    $@

    retval=$?

    sleep 1
    # un-mount
    _umount

    if [[ "$retval" != "0" ]] ; then
        echo "Failed to do '$@'"
        exit 1
    fi

    return $retval
}

if [[ $1 == "chroot" ]] ; then
    echo "Chrooting into system"
    ychroot /tools/bin/bash
    exit $?
fi

cp yaps.build.conf $YDIR/

for i in linux-api-headers glibc zlib file                    \
         readline m4 bc binutils gmp mpfr mpc shadow          \
         gcc bzip2 pkg-config ncurses attr acl libcap         \
         sed psmisc iana-etc bison flex grep bash libtool     \
         gdbm gperf expat inetutils perl xml-parser           \
         inettool autoconf xz kmod gettext elfutils           \
         libffi openssl python ninja meson coreutils          \
         check diffutils groff grub less gzip iproute2        \
         kbd libpipeline make patch man-db tar texinfo        \
         vim systemd dbus procps-ng util-linux e2fsprogs; do

    [[ -d $YDIR/usr/share/yaps/$i ]] && {
        echo "skipping $i, (already configured)"
        continue
    }

    echo "=> compiling $i"
    ychroot /tools/bin/yaps compile $i --no-depends --compiler-specs /yaps.build.conf

    case $i in
        glibc)
            [[ -e /tools/patched-toolchain ]] || {
                echo "adjusting toolchain"
                mv -v /tools/bin/{ld,ld-old}
                mv -v /tools/$(uname -m)-pc-linux-gnu/bin/{ld,ld-old}
                mv -v /tools/bin/{ld-new,ld}
                ln -sv /tools/bin/ld /tools/$(uname -m)-pc-linux-gnu/bin/ld

                gcc -dumpspecs | sed -e 's@/tools@@g'                   \
                    -e '/\*startfile_prefix_spec:/{n;s@.*@/usr/lib/ @}' \
                    -e '/\*cpp:/{n;s@$@ -isystem /usr/include@}' >      \
                    `dirname $(gcc --print-libgcc-file-name)`/specs

                touch /tools/patched-toolchain
            }

            echo "testing toolchain"
            echo 'int main(){}' > dummy.c

            cc dummy.c -v -Wl,--verbose &> dummy.log
            if [[ $(readelf -l a.out | grep ': /lib' | xargs) != '[Requesting program interpreter: /lib64/ld-linux-x86-64.so.2]' ]] ; then
                echo 'Toolchain interpreter fail' > /tools/tc-test-fail
                exit 1
            fi
            grep -o '/usr/lib.*/crt[1in].*succeeded' dummy.log || tee /tools/tc-test-fail
            grep -B1 '^ /usr/include' dummy.log || tee /tools/tc-test-fail
            grep 'SEARCH.*/usr/lib' dummy.log |sed 's|; |\n|g' || tee /tools/tc-test-fail
            grep "/lib.*/libc.so.6 " dummy.log || tee /tools/tc-test-fail
            grep found dummy.log || tee /tools/tc-test-fail
            rm -v dummy.c a.out dummy.log
            ;;
    esac
    
done
