/* BEGIN_COMMON_COPYRIGHT_HEADER
 * (c)LGPL2+
 *
 * Copyright: 2012-2013 Razor team
 * Authors:
 *   Petr Vanek <petr@scribus.info>
 *
 * Copyright: 2019 Tianjin KYLIN Information Technology Co., Ltd. *
 *
 * This program or library is free software; you can redistribute it
 * and/or modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA
 *
 * END_COMMON_COPYRIGHT_HEADER */

#ifndef DARSHANAPPLICATION_H
#define DARSHANAPPLICATION_H

#include <QApplication>
#include <QProxyStyle>
#include "darshanglobals.h"

namespace Darshan
{

/*! \brief Darshan wrapper around QApplication.
 * It loads various Darshan related stuff by default (window icon, icon theme...)
 *
 * \note This wrapper is intended to be used only inside Darshan project. Using it
 *       in external application will automatically require linking to various
 *       Darshan libraries.
 *
 */
class DARSHAN_API Application : public QApplication
{
    Q_OBJECT

public:
    /*! Construct a Darshan application object.
     * \param argc standard argc as in QApplication
     * \param argv standard argv as in QApplication
     */
    Application(int &argc, char **argv);
    /*! Construct a Darshan application object.
     * \param argc standard argc as in QApplication
     * \param argv standard argv as in QApplication
     * \param handleQuitSignals flag if signals SIGINT, SIGTERM, SIGHUP should be handled internaly (\sa quit() application)
     */
    Application(int &argc, char **argv, bool handleQuitSignals);
    virtual ~Application() {}
    /*! Install UNIX signal handler for signals defined in \param signalList
     * Upon receiving of any of this signals the \sa unixSignal signal is emitted
     */
    void listenToUnixSignals(QList<int> const & signolList);

private slots:
    void updateTheme();

signals:
    void themeChanged();
    /*! Signal is emitted upon receival of registered unix signal
     * \param signo the received unix signal number
     */
    void unixSignal(int signo);
};

#if defined(darshanApp)
#undef darshanApp
#endif
#define darshanApp (static_cast<Darshan::Application *>(qApp))

} // namespace Darshan
#endif // DARSHANAPPLICATION_H
