/* BEGIN_COMMON_COPYRIGHT_HEADER
 * (c)LGPL2+
 *
 * Copyright: 2010-2012 Razor team
 * Authors:
 *   Petr Vanek <petr@scribus.info>
 *   Kuzma Shapran <kuzma.shapran@gmail.com>
 *
 * Copyright: 2019 Tianjin KYLIN Information Technology Co., Ltd. *
 *
 * This program or library is free software; you can redistribute it
 * and/or modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA
 *
 * END_COMMON_COPYRIGHT_HEADER */


#ifndef DARSHANQUICKLAUNCHBUTTON_H
#define DARSHANQUICKLAUNCHBUTTON_H

#include "quicklaunchaction.h"
#include <QMimeData>
#include <QToolButton>
#include "../panel/customstyle.h"
#include <QStyleOption>
#include <QGSettings>
#include <QPainter>
#include "popupmenu.h"

class IDARSHANPanelPlugin;
//class CustomStyle;
#include "../panel/darshancontrolstyle.h"
class QuicklaunchMenu:public QMenu
{
public:
    QuicklaunchMenu();
    ~QuicklaunchMenu();
protected:
    void contextMenuEvent(QContextMenuEvent*);

};
class QuickLaunchButton : public QToolButton
{
    Q_OBJECT

public:
    QuickLaunchButton(QuickLaunchAction * act, IDARSHANPanelPlugin * plugin, QWidget* parent = 0);
    ~QuickLaunchButton();

    QHash<QString,QString> settingsMap();
    QString file_name;
    static QString mimeDataFormat() { return QLatin1String("x-darshan/quicklaunch-button"); }

signals:
    void buttonDeleted();
    void switchButtons(QuickLaunchButton *from, QuickLaunchButton *to);
    void movedLeft();
    void movedRight();

protected:
    //! Disable that annoying small arrow when there is a menu
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent* e);
    void dragEnterEvent(QDragEnterEvent *e);
    void dragMoveEvent(QDragMoveEvent * e);
    void contextMenuEvent(QContextMenuEvent*);
    void enterEvent(QEvent *event);
    void leaveEvent(QEvent *event);
    void dropEvent(QDropEvent *e);
    virtual QMimeData * mimeData();
    void dragLeaveEvent(QDragLeaveEvent *e);

private:
    QuickLaunchAction *mAct;
    IDARSHANPanelPlugin * mPlugin;
    QAction *mDeleteAct;
    QAction *mMoveLeftAct;
    QAction *mMoveRightAct;
    QuicklaunchMenu *mMenu;
    QPoint mDragStart;
    enum QuickLaunchStatus{NORMAL, HOVER, PRESS};
    QuickLaunchStatus quicklanuchstatus;
    CustomStyle toolbuttonstyle;
    QGSettings *mgsettings;

    void modifyQuicklaunchMenuAction(bool direction);

private slots:
    void this_customContextMenuRequested(const QPoint & pos);
public slots:
    void selfRemove();
};


class ButtonMimeData: public QMimeData
{
    Q_OBJECT
public:
    ButtonMimeData():
        QMimeData(),
        mButton(0)
    {
    }

    QuickLaunchButton *button() const { return mButton; }
    void setButton(QuickLaunchButton *button) { mButton = button; }

private:
    QuickLaunchButton *mButton;
};

#endif
