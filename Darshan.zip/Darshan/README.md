# darshan-panel
darshan-panel represents the taskbar of DARSHAN

## Table of Contents

   * [About Project](#About-Project)
   * [Getting Started](#Getting-Started)
   * [Document Introduction](#Document-Introduction)


## About Project

darshan-panel contains the following plugins:
   * startmenu 
   * quicklaunch
   * taskbar
   * tray
   * calendar
   * nightmode
   * showdesktop ...

## Getting Started

```bash
# Install darshan-panel
apt install darshan-panel

# build from source and test
mkdir build & cd build
cmake ..
make 
sudo make install
./panel/darshan-panel
```

## Document Introduction

darshan-panel has plugins configuration file in ~/.config/darshan/panel.conf   
it decide the count and order of the darshan-panel's plugins  

