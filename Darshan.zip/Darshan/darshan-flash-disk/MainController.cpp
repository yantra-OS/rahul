/*
 * Copyright (C) 2019 Tianjin KYLIN Information Technology Co., Ltd.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/&gt;.
 *
 */
#include "MainController.h"
#include <KWindowEffects>
//#include "stdlib.h"

MainController* MainController::mSelf = 0;  //static variable
MainController* MainController::self()      //static function    //complete the singleton object
{
    if (!mSelf)
    {
        mSelf = new MainController;
    }
    return mSelf;
}

MainController::MainController()
{
    init();
    m_DiskWindow = new MainWindow;         //main process singleton object
}

MainController::~MainController()
{
}

void MainController::init()                   //init select
{
    if(IsNotRunning())
    {
        creatDBusService();                 //create connect
        qDebug()<<"--------------creatDBusService";
    }
    else
    {
        qDebug()<<"darshan-flash-disk is running";  //or finish the process
        exit(0);
    }
}

int MainController::IsNotRunning()
{
    //determine the session bus that if it has been connected
    char service_name[SERVICE_NAME_SIZE];
    memset(service_name, 0, SERVICE_NAME_SIZE);
//    char *appName;
//    std::string strAppName = "darshan-flash-disk";
//    appName = strAppName.c_str();  此方法返回的是一个可读不可改的const char *类型
    char *appName;
    QString strAppName;
    QByteArray ba = strAppName.toLatin1();
    appName = ba.data();
    snprintf(service_name, SERVICE_NAME_SIZE, "%s_%d_%s",DARSHAN_FLASH_DISK_SERVICE,getuid(),strcat(appName,getenv("DISPLAY")));
    qDebug()<<"getenv(display)"<<getenv("DISPLAY");
    qDebug()<<"service_name"<<service_name;
    QDBusConnection conn = QDBusConnection::sessionBus();
    if (!conn.isConnected())
        return 0;

    QDBusReply<QString> reply = conn.interface()->call("GetNameOwner", service_name);
    return reply.value() == "";
}

void MainController::creatDBusService()
{
    // 用于建立到session bus的连接
    //to be used for creating the session bus connection
    QDBusConnection bus = QDBusConnection::sessionBus();
    // 在session bus上注册名为"com.kylin_user_guide.hotel"的service
    // register the service in session bus that named by "com.kylin_user_guide.hotel"

    char service_name[SERVICE_NAME_SIZE];
    memset(service_name, 0, SERVICE_NAME_SIZE);
    snprintf(service_name, SERVICE_NAME_SIZE, "%s_%d",DARSHAN_FLASH_DISK_SERVICE,getuid());

    if (!bus.registerService(service_name))
    {  //注意命名规则-和_
       //Note the naming convention.
            qDebug() << bus.lastError().message();
            exit(1);
    }
    // "QDBusConnection::ExportAllSlots"表示把类Hotel的所有Slot都导出为这个Object的method
    // "QDBusConnection::ExportAllSlots" stands for that it makes all the slot in class hotel export to the method of this object
    bus.registerObject("/", this ,QDBusConnection::ExportAllSlots);
}
