<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr" sourcelanguage="tr">
<context>
    <name>ejectInterface</name>
    <message>
        <location filename="ejectInterface.cpp" line="17"/>
        <source>usb has been unplugged safely</source>
        <translation>USB güvenli bir şekilde çıkarıldı</translation>
    </message>

</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="42"/>
        <source>usb management tool</source>
        <translation>Usb yönetim aracı</translation>
    </message>
</context>

<context>
    <name>QClickWidget</name>
    <message>
        <location filename="qclickWidget.cpp" line="74"/>
        <source>eject</source>
        <translation>Çıkar</translation>
    </message>
    <message>
        <location filename="qclickWidget.cpp" line="711"/>
        <source>the capacity is empty</source>
        <translation>Kapasite boş</translation>
    </message>
</context>
</TS>
