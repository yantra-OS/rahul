<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../build/darshan-flash-disk_autogen/include/ui_mainwindow.h" line="40"/>
        <location filename="../ui_mainwindow.h" line="40"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="119"/>
        <source>usb management tool</source>
        <translation type="unfinished">U盘管理工具</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="143"/>
        <location filename="../mainwindow.cpp" line="161"/>
        <source>darshan-flash-disk</source>
        <translation type="unfinished">U盘管理工具</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="146"/>
        <source>kindly reminder</source>
        <translation type="unfinished">温馨提示</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="164"/>
        <source>wrong reminder</source>
        <translation type="unfinished">错误提示</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="276"/>
        <source>Please do not pull out the USB flash disk when reading or writing</source>
        <translation type="unfinished">U盘读写时请不要直接拔出</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="296"/>
        <source>There is a problem with this device</source>
        <translation type="unfinished">此设备存在问题</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1386"/>
        <source>telephone device</source>
        <translation type="unfinished">手机设备</translation>
    </message>
</context>
<context>
    <name>QClickWidget</name>
    <message>
        <location filename="../qclickwidget.cpp" line="195"/>
        <source>弹出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qclickwidget.cpp" line="775"/>
        <source>the capacity is empty</source>
        <translation type="unfinished">容量为空</translation>
    </message>
    <message>
        <location filename="../qclickwidget.cpp" line="781"/>
        <source>blank CD</source>
        <translation type="unfinished">空光盘</translation>
    </message>
    <message>
        <location filename="../qclickwidget.cpp" line="784"/>
        <source>other user device</source>
        <translation type="unfinished">其它用户设备</translation>
    </message>
    <message>
        <source>another device</source>
        <translation type="obsolete">其它设备</translation>
    </message>
</context>
<context>
    <name>ejectInterface</name>
    <message>
        <location filename="../ejectInterface.cpp" line="55"/>
        <source>usb has been unplugged safely</source>
        <translation type="unfinished">U盘已安全拔出</translation>
    </message>
    <message>
        <location filename="../ejectInterface.cpp" line="56"/>
        <source>usb is occupying unejectable</source>
        <translation type="unfinished">U盘占用无法弹出</translation>
    </message>
    <message>
        <location filename="../ejectInterface.cpp" line="57"/>
        <source>data device has been unloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ejectInterface.cpp" line="58"/>
        <source>gparted has started</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gpartedInterface</name>
    <message>
        <location filename="../gpartedinterface.cpp" line="61"/>
        <source>gparted has started,can not eject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gpartedinterface.cpp" line="62"/>
        <source>ok</source>
        <translation type="unfinished">确定</translation>
    </message>
</context>
<context>
    <name>interactiveDialog</name>
    <message>
        <location filename="../interactivedialog.cpp" line="72"/>
        <source>usb is occupying,do you want to eject it</source>
        <translation type="unfinished">U盘正在占用中，你想弹出它吗</translation>
    </message>
    <message>
        <location filename="../interactivedialog.cpp" line="77"/>
        <source>cancle</source>
        <translation type="unfinished">取消</translation>
    </message>
    <message>
        <location filename="../interactivedialog.cpp" line="81"/>
        <source>yes</source>
        <translation type="unfinished">确定</translation>
    </message>
</context>
</TS>
